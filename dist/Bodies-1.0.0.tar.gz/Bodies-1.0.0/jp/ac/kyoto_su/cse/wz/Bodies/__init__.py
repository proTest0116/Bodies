#! /usr/bin/env python
# -*- coding: utf-8 -*-

"""パッケージに必要な「__init__.py」ファイル。"""

# print "*** Boadies ***"