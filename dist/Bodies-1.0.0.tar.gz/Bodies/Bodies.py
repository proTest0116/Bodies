#! /usr/bin/env python
# -*- codinf: utf-8 -*-

import sys

import jp.ac.kyoto_su.cse.wz.Bodies.Example as Example

if __name__ == '__main__':
    sys.exit(Example.main())