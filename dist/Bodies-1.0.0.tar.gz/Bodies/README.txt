Bodies is open source software. And, The software draw 3D model.
if you’d like to test Bodies, Type as below to Terminal.app

$ make test

We use as reference by AOKI Atsushi.The reference puts to below.
http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/Python/DragonPrgrammingProcess/index-j.html

———————————————————————————————————————————————


Copyright WZ 2015 TSUZAKI Takehiro,HUSE Nobumichi All rights reserved.

This program is free software; you can redistribute it and /or modify it under the terms of the GNU General Public License as published by the Free Software Foundation;

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY WZ “AS IS” AND ANY EXPRESS OR IMPLED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL WZ OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the authors and should not be interpreted as representing official policies, either expressed or implied, of WZ.

You should have received a copy of the GNU General Public License along with this program.if not see <http://www.gnu/license/>.

 (c) AOKI Atsushi All right reserved.